# 🌩️ MyMiniCloud – Hệ Thống MiniCloud 9 Server

Dự án mô phỏng hạ tầng đám mây (Cloud Platform) với **9 loại server** chạy trong Docker containers, kết nối qua mạng nội bộ `cloud-net`.

---

## 📁 Cấu Trúc Thư Mục

```
hotenSVminicloud/
├── web-frontend-server/          # Server 1: Nginx static site
│   ├── Dockerfile
│   ├── conf.default              # Nginx server block
│   └── html/
│       ├── index.html            # Trang chủ
│       └── blog/
│           ├── index.html        # Danh sách blog
│           ├── blog1.html        # Bài viết: Docker & Cloud
│           ├── blog2.html        # Bài viết: Du lịch Đà Lạt
│           └── blog3.html        # Bài viết: Học Cloud Computing
├── application-backend-server/   # Server 2: Flask API
│   ├── Dockerfile
│   ├── app.py                    # Flask app với tất cả endpoints
│   └── students.json             # Dữ liệu sinh viên (5 records)
├── relational-database-server/   # Server 3: MariaDB
│   └── init/
│       └── 001_init.sql          # Tạo minicloud + studentdb
├── authentication-identity-server/  # Server 4: Keycloak
├── object-storage-server/        # Server 5: MinIO
│   └── data/
├── internal-dns-server/          # Server 6: Bind9
│   ├── named.conf.options
│   ├── named.conf.local
│   └── db.cloud.local
├── monitoring-prometheus-server/ # Server 7: Prometheus
│   └── prometheus.yml
├── monitoring-grafana-dashboard-server/  # Server 8: Grafana
├── api-gateway-proxy-server/     # Server 9: Nginx Reverse Proxy
│   └── nginx.conf
└── docker-compose.yml            # Khởi động toàn hệ thống
```

---

## 🚀 Hướng Dẫn Khởi Động

### Bước 1: Dọn sạch container cũ
```bash
docker rm -f $(docker ps -aq)
docker ps
```

### Bước 2: Build và khởi động toàn bộ hệ thống
```bash
cd hotenSVminicloud
docker compose build --no-cache
docker compose up -d
docker compose ps
```

### Bước 3: Kiểm tra tất cả container đang chạy
```bash
docker compose ps
```

---

## 🔍 Kiểm Thử Từng Server

### 1. Web Frontend Server (port 8080)
```bash
curl -I http://localhost:8080/
curl -I http://localhost:8080/blog/
# Kỳ vọng: HTTP/1.1 200 OK
```
Truy cập browser: http://localhost:8080

---

### 2. Application Backend Server (port 8085)
```bash
curl http://localhost:8085/hello
curl http://localhost/api/hello
# Kỳ vọng: {"message":"Hello from App Server! (public)"}

# Mở rộng #2: API sinh viên từ JSON
curl http://localhost:8085/student
curl http://localhost/api/student

# Mở rộng #3: API sinh viên từ Database
curl http://localhost:8085/students-db
curl http://localhost/api/students-db
```

---

### 3. Relational Database Server (port 3306)
```bash
docker run -it --rm --network cloud-net mysql:8 \
  sh -lc 'mysql -h relational-database-server -uroot -proot \
  -e "USE minicloud; SHOW TABLES; SELECT * FROM notes;"'

# Mở rộng #3: Kiểm tra studentdb
docker run -it --rm --network cloud-net mysql:8 \
  sh -lc 'mysql -h relational-database-server -uroot -proot \
  -e "USE studentdb; SELECT * FROM students;"'
```

---

### 4. Authentication Server – Keycloak (port 8081)
```
Truy cập: http://localhost:8081
Username: admin
Password: admin
```
- Đăng nhập vào giao diện quản trị
- Tạo user test (sv01)

---

### 5. Object Storage – MinIO (port 9001)
```
Truy cập: http://localhost:9001
Username: minioadmin
Password: minioadmin
```
- Tạo bucket `demo`
- Upload file `index.html`

---

### 6. Internal DNS Server (port 1053)
```bash
dig @127.0.0.1 -p 1053 web-frontend-server.cloud.local +short
# Kỳ vọng: 10.10.10.10

# Mở rộng #6: Kiểm tra các bản ghi mở rộng
dig @127.0.0.1 -p 1053 app-backend.cloud.local +short
dig @127.0.0.1 -p 1053 minio.cloud.local +short
dig @127.0.0.1 -p 1053 keycloak.cloud.local +short
```

---

### 7. Monitoring – Prometheus (port 9090)
```
Truy cập: http://localhost:9090
→ Status → Targets
→ Kiểm tra monitoring-node-exporter-server:9100 phải UP
→ Graph: node_cpu_seconds_total
```

---

### 8. Logging / Visualization – Grafana (port 3000)
```
Truy cập: http://localhost:3000
Username: admin
Password: admin

Cấu hình:
1. Connections → Data sources → Add → Prometheus
2. URL: http://monitoring-prometheus-server:9090
3. Save & Test
4. Dashboards → Import → ID: 1860 (Node Exporter Full)
```

---

### 9. API Gateway / Reverse Proxy (port 80)
```bash
curl -I http://localhost/
# → 200 OK (web)

curl -s http://localhost/api/hello
# → JSON từ backend

curl -I http://localhost/auth/
# → redirect đến Keycloak

curl http://localhost/student/
# → danh sách sinh viên JSON (Mở rộng #9)
```

---

### 10. Kiểm Tra Kết Nối Mạng (Ping)
```bash
docker exec -it api-gateway-proxy-server sh -c "
  ping -c 3 web-frontend-server
  ping -c 3 application-backend-server
  ping -c 3 relational-database-server
  ping -c 3 authentication-identity-server
  ping -c 3 object-storage-server
  ping -c 3 monitoring-prometheus-server
  ping -c 3 monitoring-grafana-dashboard-server
  ping -c 3 internal-dns-server
"
```

---

## 🔧 Cổng Dịch Vụ

| Service | Container | Port |
|---------|-----------|------|
| Web Frontend | web-frontend-server | 8080 |
| App Backend | application-backend-server | 8085 |
| Database | relational-database-server | 3306 |
| Auth (Keycloak) | authentication-identity-server | 8081 |
| MinIO API | object-storage-server | 9000 |
| MinIO Console | object-storage-server | 9001 |
| DNS | internal-dns-server | 1053/udp |
| Node Exporter | monitoring-node-exporter-server | 9100 |
| Prometheus | monitoring-prometheus-server | 9090 |
| Grafana | monitoring-grafana-dashboard-server | 3000 |
| Reverse Proxy | api-gateway-proxy-server | 80 |

---

## ✅ Bảng Kiểm Tra Yêu Cầu Mở Rộng

| # | Server | Yêu Cầu | Trạng Thái |
|---|--------|----------|------------|
| 1 | Web Frontend | Blog 3 bài (blog1–3.html) | ✅ |
| 2 | App Backend | API /student từ JSON | ✅ |
| 3 | Database | DB studentdb + bảng students | ✅ |
| 4 | Keycloak | Realm + client + user | 🔧 Cấu hình thủ công qua UI |
| 5 | MinIO | Bucket + upload file | 🔧 Thực hiện qua Console UI |
| 6 | DNS | Bản ghi app-backend, minio, keycloak | ✅ |
| 7 | Prometheus | Thêm scrape target web | ✅ |
| 8 | Grafana | Dashboard 3 biểu đồ | 🔧 Tạo thủ công qua UI |
| 9 | Proxy | Route /student/ → backend | ✅ |
| 10 | Load Balancer | Round Robin upstream | ✅ |

---

## 📦 Push Image Lên Docker Hub

```bash
# Login Docker Hub
docker login

# Tag image
docker tag hotensv/web:dev YOUR_DOCKERHUB_USERNAME/myminicloud-web:latest
docker tag hotensv/app:dev YOUR_DOCKERHUB_USERNAME/myminicloud-app:latest

# Push
docker push YOUR_DOCKERHUB_USERNAME/myminicloud-web:latest
docker push YOUR_DOCKERHUB_USERNAME/myminicloud-app:latest
```

---

## ☁️ Deploy lên AWS EC2

```bash
# 1. Kết nối EC2
ssh -i your-key.pem ubuntu@YOUR_EC2_PUBLIC_IP

# 2. Cài Docker
sudo apt update && sudo apt install -y docker.io docker-compose-v2
sudo usermod -aG docker ubuntu
newgrp docker

# 3. Clone/copy project lên EC2
scp -r hotenSVminicloud ubuntu@YOUR_EC2_PUBLIC_IP:~/

# 4. Khởi động
cd ~/hotenSVminicloud
docker compose up -d

# 5. Mở Security Group cho các port: 80, 8080, 8081, 8085, 9000, 9001, 9090, 3000
```
